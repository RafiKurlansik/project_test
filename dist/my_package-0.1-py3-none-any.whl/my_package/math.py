# Databricks notebook source
## Databricks notebook source

def squared (x):
  return x * x